def clean_documents(rows):
    """输入必须为list，否则TypeError。跳过非dict、非字符串/空白id或title。
    id/title去首尾空白；重复id保留首个有效条目；仅输出id/title；不修改输入。
    """
    raise NotImplementedError('请按契约实现，再运行测试')
