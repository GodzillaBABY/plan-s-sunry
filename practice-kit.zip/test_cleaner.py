import unittest
from copy import deepcopy
from cleaner import clean_documents
class CleanerTests(unittest.TestCase):
    def test_normal(self):
        self.assertEqual(clean_documents([{'id':' a ','title':' 文档 ','extra':1}]),[{'id':'a','title':'文档'}])
    def test_empty(self): self.assertEqual(clean_documents([]),[])
    def test_duplicates(self):
        self.assertEqual(clean_documents([{'id':'a','title':'一'},{'id':' a ','title':'二'}]),[{'id':'a','title':'一'}])
    def test_invalid(self):
        self.assertEqual(clean_documents([None,1,{}, {'id':1,'title':'a'}, {'id':'a','title':None}, {'id':' ','title':'a'},{'id':'a','title':' '}]),[])
    def test_invalid_first_does_not_block_valid(self):
        self.assertEqual(clean_documents([{'id':'a','title':''},{'id':'a','title':'有效'}]),[{'id':'a','title':'有效'}])
    def test_input_type(self):
        for value in [None,{},'x',1]:
            with self.subTest(value=value):
                with self.assertRaises(TypeError): clean_documents(value)
    def test_non_mutation(self):
        data=[{'id':' a ','title':'文档','tags':['x']}]; before=deepcopy(data)
        clean_documents(data); self.assertEqual(data,before)
    def test_repeatable(self):
        data=[{'id':'a','title':'文档'}]
        self.assertEqual(clean_documents(data),clean_documents(data))
        self.assertEqual(clean_documents(clean_documents(data)),clean_documents(data))
if __name__=='__main__': unittest.main()
