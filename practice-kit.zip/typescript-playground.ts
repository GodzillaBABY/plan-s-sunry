// 整份复制进 https://www.typescriptlang.org/play/ ，开启 strict 后运行。
// 契约：unknown输入必须是具有非空字符串id/title的对象；去首尾空白，仅返回两个字段。
// 无效输入抛Error；禁止any和类型断言绕过检查。
type Doc = { id: string; title: string };
function parseDocument(input: unknown): Doc {
  throw new Error('TODO: 实现运行时校验与类型收窄');
}
function assert(ok: boolean, label: string) { if (!ok) throw new Error(label); }
const valid = parseDocument({id:' a ', title:' 文档 ', extra:1});
assert(JSON.stringify(valid) === JSON.stringify({id:'a',title:'文档'}), '正常输入与去空白');
for (const input of [null, undefined, 1, [], {}, {id:1,title:'a'}, {id:'a',title:null}, {id:' ',title:'a'}, {id:'a',title:' '}]) {
  let threw = false;
  try { parseDocument(input); } catch { threw = true; }
  assert(threw, '无效输入必须拒绝: '+JSON.stringify(input));
}
const original = {id:' a ',title:' t '};
parseDocument(original);
assert(original.id === ' a ', '不得修改输入');
console.log('全部运行时用例通过；请再补一个自己的边界测试');
